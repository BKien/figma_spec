---
artifact_type: api-contract
status: Frozen
api_id: API-UC-10-03
related_uc_id: UC-10
---

# API-UC-10-03: DELETE /api/v1/job-seeker/introduction-video

## General Information

### API ID

`API-UC-10-03`

### API Name

Record and Manage an Introduction Video — DELETE /api/v1/job-seeker/introduction-video

### Related Use Case IDs

- `UC-10`

### Method

`DELETE`

### Path

`/api/v1/job-seeker/introduction-video`

### Description

Provides the wire operation referenced by the supplied Record and Manage an Introduction Video specification.

### Authentication

Authentication context is supplied when required by the preserved source contract.

### Authorization

The service evaluates the submitted operation context.

## Request Header(s)

None.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Indicates a successful protocol outcome.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Contains the operation-specific response fields defined by the preserved source contract.

Example: `{}`

Validation: Must be encoded as a JSON object.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Contains the public protocol error.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable public error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

Detailed endpoint fields, status codes, examples, and public outcomes are preserved in [the supplied source](../../source/dh-dental-uc-10-manage-introduction-video.md). Business behavior is specified by [UC-10](../uc/uc-10-manage-introduction-video.md).
