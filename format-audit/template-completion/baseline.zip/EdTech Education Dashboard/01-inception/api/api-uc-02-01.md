---
artifact_type: api-contract
status: Frozen
api_id: API-UC-02-01
related_uc_id: UC-02
---

# API-UC-02-01: POST /api/v1/auth/login

## General Information

### API ID

`API-UC-02-01`

### API Name

Sign In to a Student Account — POST /api/v1/auth/login

### Related Use Case IDs

- `UC-02`

### Method

`POST`

### Path

`/api/v1/auth/login`

### Description

Provides the wire operation referenced by the supplied Sign In to a Student Account specification.

### Authentication

Authentication context is supplied when required by the preserved source contract.

### Authorization

The service evaluates the submitted operation context.

## Request Header(s)

### headers.Content-Type

Type: string; Format: MIME type; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Declares the request representation.

Example: `application/json`

Note: Not specified.

Allowed values: application/json

Validation: Must identify the `application/json` media type.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

### payload

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Carries the operation-specific request fields defined by the preserved source contract.

Example: `{}`

Validation: Must be encoded as a JSON object.

## Success Response — HTTP 201

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Indicates a successful protocol outcome.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Contains the operation-specific response fields defined by the preserved source contract.

Example: `{}`

Validation: Must be encoded as a JSON object.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Contains the public protocol error.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable public error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

Detailed endpoint fields, status codes, examples, and public outcomes are preserved in [the supplied source](../../source/edtech-uc-02-sign-in.md). Business behavior is specified by [UC-02](../uc/uc-02-sign-in.md).
