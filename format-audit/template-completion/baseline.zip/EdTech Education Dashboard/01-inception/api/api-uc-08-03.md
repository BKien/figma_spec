---
artifact_type: api-contract
status: Frozen
api_id: API-UC-08-03
related_uc_id: UC-08
---

# API-UC-08-03: GET /api/v1/student/courses/:courseId/units/:unitId/video/media

## General Information

### API ID

`API-UC-08-03`

### API Name

Watch a Video Lesson and Save Progress — GET /api/v1/student/courses/:courseId/units/:unitId/video/media

### Related Use Case IDs

- `UC-08`

### Method

`GET`

### Path

`/api/v1/student/courses/:courseId/units/:unitId/video/media`

### Description

Provides the wire operation referenced by the supplied Watch a Video Lesson and Save Progress specification.

### Authentication

Authentication context is supplied when required by the preserved source contract.

### Authorization

The service evaluates the submitted operation context.

## Request Header(s)

None.

## Path Parameter(s)

### path.courseId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Identifies the requested path resource on the wire.

Example: `example-courseId`

Validation: Must be encoded as an opaque path string.

### path.unitId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Identifies the requested path resource on the wire.

Example: `example-unitId`

Validation: Must be encoded as an opaque path string.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Indicates a successful protocol outcome.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Contains the operation-specific response fields defined by the preserved source contract.

Example: `{}`

Validation: Must be encoded as a JSON object.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Contains the public protocol error.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable public error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

Detailed endpoint fields, status codes, examples, and public outcomes are preserved in [the supplied source](../../source/edtech-uc-08-watch-video-lesson.md). Business behavior is specified by [UC-08](../uc/uc-08-watch-video-lesson.md).
