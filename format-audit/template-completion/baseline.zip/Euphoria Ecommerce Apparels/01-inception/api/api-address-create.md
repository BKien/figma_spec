---
artifact_type: api-contract
status: Frozen
api_id: API-ADDRESS-CREATE
related_uc_id: UC-13
---

# API-ADDRESS-CREATE: Add address

## General Information

### API ID

`API-ADDRESS-CREATE`

### API Name

Add address.

### Related Use Case IDs

- `UC-13` — [specification](../uc/uc-13-add-address.md)

### Method

`POST`

### Path

`/v1/me/addresses`

### Description

Add address for the web client. Request and response objects are defined in [common wire definitions](common-contract.md).

### Authentication

Cookie named euphoria_session.

### Authorization

Access outcomes are represented by HTTP 401 and HTTP 403.

## Request Header(s)

### headers.Accept

Type: string.; Format: Not specified.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Response media type.

Example: `"application/json"`.

Note: Not specified.

Default: None.

Validation: HTTP media type syntax; allowed value application/json.

### headers.Content-Type

Type: string.; Format: Not specified.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Request media type.

Example: `"application/json"`.

Note: Not specified.

Default: None.

Validation: HTTP media type syntax; allowed value application/json.

### headers.Cookie

Type: string.; Format: Not specified.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: HTTP cookie encoding; euphoria_session carries an opaque value.

Example: `"euphoria_session=opaque-session-value"`.

Note: Not specified.

Default: None.

Validation: HTTP Cookie header encoding.

### headers.X-CSRF-Token

Type: string.; Format: Not specified.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque request header value.

Example: `"opaque-csrf-value"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

### body

Type: NewAddress.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: JSON object; full NewAddress field definitions are in common-contract.md.

Example: `{"details": {"firstName": "Alex", "lastName": "Lee", "country": "US", "company": null, "street": "10 Sample Street", "unit": null, "city": "Sample City", "state": "CA", "postalCode": "90001", "phone": "+12025550123", "instructions": null}, "defaultShipping": false, "defaultBilling": false, "expectedVersion": 1}`.

~~~json
{
  "details": {
    "firstName": "Alex",
    "lastName": "Lee",
    "country": "US",
    "company": null,
    "street": "10 Sample Street",
    "unit": null,
    "city": "Sample City",
    "state": "CA",
    "postalCode": "90001",
    "phone": "+12025550123",
    "instructions": null
  },
  "defaultShipping": false,
  "defaultBilling": false,
  "expectedVersion": 1
}
~~~

Default: None.

Validation: Object or array shape defined in common-contract.md.

## Success Response — HTTP 200

Content-Type: application/json.

### data

Type: AddressBook.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: AddressBook object; all nested fields are defined in common-contract.md.

Example: `{"version": 1, "items": [{"id": "addr_01", "details": {"firstName": "Alex", "lastName": "Lee", "country": "US", "company": null, "street": "10 Sample Street", "unit": null, "city": "Sample City", "state": "CA", "postalCode": "90001", "phone": "+12025550123", "instructions": null}, "defaultShipping": false, "defaultBilling": false}]}`.

Default: None.

Validation: Object or array shape defined in common-contract.md.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

~~~json
{
  "data": {
    "version": 1,
    "items": [
      {
        "id": "addr_01",
        "details": {
          "firstName": "Alex",
          "lastName": "Lee",
          "country": "US",
          "company": null,
          "street": "10 Sample Street",
          "unit": null,
          "city": "Sample City",
          "state": "CA",
          "postalCode": "90001",
          "phone": "+12025550123",
          "instructions": null
        },
        "defaultShipping": false,
        "defaultBilling": false
      }
    ]
  },
  "requestId": "req_01"
}
~~~

Default: None.

Validation: JSON type only.

## Error Response — HTTP 400

Trigger: Malformed wire input.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "MALFORMED_REQUEST", "message": "Malformed wire input."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: MALFORMED_REQUEST.

Example: `"MALFORMED_REQUEST"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Malformed wire input."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 401

Trigger: Rejected authentication context.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "AUTHENTICATION_REJECTED", "message": "Rejected authentication context."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: AUTHENTICATION_REJECTED.

Example: `"AUTHENTICATION_REJECTED"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Rejected authentication context."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 403

Trigger: Rejected access context.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "ACCESS_REJECTED", "message": "Rejected access context."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: ACCESS_REJECTED.

Example: `"ACCESS_REJECTED"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Rejected access context."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 409

Trigger: Operation conflict.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "OPERATION_CONFLICT", "message": "Operation conflict."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: OPERATION_CONFLICT.

Example: `"OPERATION_CONFLICT"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Operation conflict."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 422

Trigger: Operation rejected.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "REQUEST_REJECTED", "message": "Operation rejected."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: REQUEST_REJECTED.

Example: `"REQUEST_REJECTED"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Operation rejected."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 503

Trigger: Temporary service failure.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "SERVICE_UNAVAILABLE", "message": "Temporary service failure."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: SERVICE_UNAVAILABLE.

Example: `"SERVICE_UNAVAILABLE"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Temporary service failure."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Notes

This is a proposed contract, not a discovered endpoint. Field definitions in [common wire definitions](common-contract.md) are part of this contract. There are no pagination parameters in this version. All declared errors use the stated JSON envelope.
