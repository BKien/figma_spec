---
artifact_type: api-contract
status: Frozen
api_id: API-ORDERS
related_uc_ids: ["UC-16", "UC-17"]
---

# API-ORDERS: Read order history

## General Information

### API ID

`API-ORDERS`

### API Name

Read order history.

### Related Use Case IDs

- `UC-16` — [specification](../uc/uc-16-view-order-history.md)
- `UC-17` — [specification](../uc/uc-17-filter-order-history.md)

### Method

`GET`

### Path

`/v1/me/orders`

### Description

Read order history for the web client. Request and response objects are defined in [common wire definitions](common-contract.md).

### Authentication

Cookie named euphoria_session.

### Authorization

Access outcomes are represented by HTTP 401 and HTTP 403.

## Request Header(s)

### headers.Accept

Type: string.; Format: Not specified.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Response media type.

Example: `"application/json"`.

Note: Not specified.

Default: None.

Validation: HTTP media type syntax; allowed value application/json.

### headers.Cookie

Type: string.; Format: Not specified.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: HTTP cookie encoding; euphoria_session carries an opaque value.

Example: `"euphoria_session=opaque-session-value"`.

Note: Not specified.

Default: None.

Validation: HTTP Cookie header encoding.

## Path Parameter(s)

None.

## Query Parameter(s)

### query.tab

Type: string.; Required: No.; Nullable: No.

Trigger: Not specified.

Description: Public enum: ACTIVE, CANCELLED, COMPLETED.

Example: `"ACTIVE"`.

Default: None.

Validation: Membership in the public enum stated in the description.

## Request Body

None.

## Success Response — HTTP 200

Content-Type: application/json.

### data

Type: OrderResult.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: OrderResult object; all nested fields are defined in common-contract.md.

Example: `{"items": [{"id": "ord_01", "number": "EU-1001", "placedAt": "2026-09-24T02:00:00Z", "status": "PLACED", "paymentMethod": "COD", "estimatedDelivery": null, "total": {"amount": "34.00", "currency": "USD"}, "items": [{"id": "cl_01", "variantId": "var_01", "title": "Printed shirt", "imageUrl": "https://example.com/shirt.jpg", "color": "Black", "size": "M", "quantity": 1, "unitPrice": {"amount": "29.00", "currency": "USD"}, "lineTotal": {"amount": "29.00", "currency": "USD"}}]}]}`.

Default: None.

Validation: Object or array shape defined in common-contract.md.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

~~~json
{
  "data": {
    "items": [
      {
        "id": "ord_01",
        "number": "EU-1001",
        "placedAt": "2026-09-24T02:00:00Z",
        "status": "PLACED",
        "paymentMethod": "COD",
        "estimatedDelivery": null,
        "total": {
          "amount": "34.00",
          "currency": "USD"
        },
        "items": [
          {
            "id": "cl_01",
            "variantId": "var_01",
            "title": "Printed shirt",
            "imageUrl": "https://example.com/shirt.jpg",
            "color": "Black",
            "size": "M",
            "quantity": 1,
            "unitPrice": {
              "amount": "29.00",
              "currency": "USD"
            },
            "lineTotal": {
              "amount": "29.00",
              "currency": "USD"
            }
          }
        ]
      }
    ]
  },
  "requestId": "req_01"
}
~~~

Default: None.

Validation: JSON type only.

## Error Response — HTTP 400

Trigger: Malformed wire input.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "MALFORMED_REQUEST", "message": "Malformed wire input."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: MALFORMED_REQUEST.

Example: `"MALFORMED_REQUEST"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Malformed wire input."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 401

Trigger: Rejected authentication context.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "AUTHENTICATION_REJECTED", "message": "Rejected authentication context."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: AUTHENTICATION_REJECTED.

Example: `"AUTHENTICATION_REJECTED"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Rejected authentication context."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 403

Trigger: Rejected access context.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "ACCESS_REJECTED", "message": "Rejected access context."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: ACCESS_REJECTED.

Example: `"ACCESS_REJECTED"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Rejected access context."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Error Response — HTTP 503

Trigger: Temporary service failure.

Content-Type: application/json.

### error

Type: object.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Error object with code and message.

Example: `{"code": "SERVICE_UNAVAILABLE", "message": "Temporary service failure."}`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### error.code

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Public enum: SERVICE_UNAVAILABLE.

Example: `"SERVICE_UNAVAILABLE"`.

Note: Not specified.

Default: None.

Validation: Membership in the public enum stated in the description.

### error.message

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Display message.

Example: `"Temporary service failure."`.

Note: Not specified.

Default: None.

Validation: JSON type only.

### requestId

Type: string.; Required: Yes.; Nullable: No.

Trigger: Not specified.

Description: Opaque response correlation identifier.

Example: `"req_01"`.

Note: Not specified.

Default: None.

Validation: JSON type only.

## Notes

This is a proposed contract, not a discovered endpoint. Field definitions in [common wire definitions](common-contract.md) are part of this contract. There are no pagination parameters in this version. All declared errors use the stated JSON envelope.
