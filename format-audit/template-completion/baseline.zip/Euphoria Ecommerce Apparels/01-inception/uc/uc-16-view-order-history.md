---
artifact_type: business-use-case-specification
status: Frozen
uc_id: UC-16
uc_name: "View order history"
---

# UC-16: View order history

## Functional Use-Case Specification

### Use Case ID

UC-16

### Use Case Name

View order history

### Description

Open My Orders and read the displayed summaries before opening a selected order.

### Actor(s)

Primary: Customer. Supporting: web client and application service.

### Priority

Medium.

### Trigger

The customer chooses My orders.

### Pre-Condition(s)

PRE-1: The My Account area is displayed.

### Post-Condition(s)

POST-1: The client displays the returned order summaries.

### Basic Flow

1. The customer chooses My orders.
2. The client requests the displayed tab.
3. The system returns order summaries.
4. The client displays order numbers, dates, statuses, delivery estimates, payment labels, items, and totals.
5. The customer opens an order.
6. The client requests and displays its detail.

### Alternative Flow

AF-1: Return to My Info

5a: The customer returns to My Info.

5b: The client opens My Info.

### Exception Flow

EF-1: Retry the order list

3a: The system returns a temporary service failure.

3b: The client presents a retry action in the order list.

### Related UI

- [Figma node 290:1372](https://www.figma.com/design/WcpUgAYaQJA4J00rMaMgj8/Euphoria?node-id=290-1372)

### Related API IDs

- [API-ORDERS](../api/api-orders.md)
- [API-ORDER-DETAIL](../api/api-order-detail.md)

### Notes

Screen and text-layer evidence establishes the visible goal. Service decomposition, request shapes, and exception recovery are proposed implementation contracts; they are not extracted server behavior. See [assumptions](../../ASSUMPTIONS.md) and [coverage](../../coverage-report.md) for the supported boundary. No prototype interaction wiring was available for verification.

## UML Model

~~~plantuml
@startuml
hide empty members

class OrderService {
  +list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
}

class Money <<value>> {
  amount: Real
  currency: String
}

class Order {
  id: String
  number: String
  customerId: String
  placedAt: Integer
  status: OrderStatus
  paymentMethod: PaymentMethod
  items: Sequence(OrderLine)
  total: Money
}

class OrderLine {
  id: String
}

enum OrderStatus {
  PLACED
  IN_PROGRESS
  SHIPPED
  DELIVERED
  CANCELLED
}

enum OrderTab {
  ACTIVE
  CANCELLED
  COMPLETED
}

enum PaymentMethod {
  COD
}

class RequestContext <<input>> {
  customerId: String
  authenticated: Boolean
}

Order "1" *-- "1..*" OrderLine
Order --> "1" OrderStatus : status
Order --> "1" PaymentMethod : paymentMethod
Order --> "1" Money : total

@enduml
~~~

## Business Rules

~~~ocl
-- BR-UC-16-01
-- Source: Assumption
context OrderService::list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
pre BR_UC_16_01_AccountContext:
  ctx.authenticated
~~~
~~~ocl
-- BR-UC-16-02
-- Source: Assumption
context OrderService::list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
post BR_UC_16_02_CustomerSummaries:
  result->forAll(o | o.customerId = ctx.customerId)
~~~
~~~ocl
-- BR-UC-16-03
-- Source: Assumption
context OrderService::list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
post BR_UC_16_03_DistinctOrders:
  result->isUnique(id)
~~~
~~~ocl
-- BR-UC-16-04
-- Source: Assumption
context OrderService::list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
post BR_UC_16_04_RecentFirst:
  result->forAll(a,b | a.placedAt > b.placedAt implies result->indexOf(a) < result->indexOf(b))
~~~
~~~ocl
-- BR-UC-16-05
-- Source: Assumption
context OrderService::list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
post BR_UC_16_05_PlacementTies:
  result->forAll(a,b | a.placedAt = b.placedAt and a.number < b.number implies result->indexOf(a) < result->indexOf(b))
~~~
~~~ocl
-- BR-UC-16-06
-- Source: Assumption
context Order
inv BR_UC_16_06_OrderNumberIdentity:
  Order.allInstances()->isUnique(number)
~~~
~~~ocl
-- BR-UC-16-07
-- Source: Assumption
context OrderService::list(ctx: RequestContext, tab: OrderTab): Sequence(Order)
post BR_UC_16_07_SummarySnapshotPreserved:
  Order.allInstances()->forAll(o | o.status = o.status@pre and o.total = o.total@pre and o.paymentMethod = o.paymentMethod@pre and o.placedAt = o.placedAt@pre and o.items = o.items@pre)
~~~
