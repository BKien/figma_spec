---
artifact_type: api-contract
status: Frozen
api_id: API-ACCOUNT-LIST
related_uc_ids: ["UC-04", "UC-05"]
---

# API-ACCOUNT-LIST: List User Accounts

## General Information

### API ID

`API-ACCOUNT-LIST`

### API Name

List User Accounts

### Related Use Case IDs

`UC-04`, `UC-05`

### Method

`GET`

### Path

`/api/v1/accounts`

### Description

Return all bank accounts owned by the authenticated user.

### Authentication

Bearer JWT in the Authorization header.

### Authorization

Authenticated request context.

## Request Header(s)

### headers.Authorization

Type: string; Format: Not specified.; Required: Yes; Nullable: No

Trigger: Request containing this field.

Description: Bearer authentication header.

Example: `Bearer <access-token>`

Note: Not specified.

Validation: Matches the declared JSON type.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Response outcome flag.

Example: `true`

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable response message.

Example: `Operation completed`

Validation: JSON string.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Operation payload.

Example: `{}`

Validation: JSON object.

### data.user_id

Type: integer; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Authenticated user identifier.

Example: `1`

Validation: JSON integer.

### data.accounts

Type: array<object>; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Array of accounts. May be empty.

Example: `[]`

Validation: JSON array<object>.

### data.accounts[].id

Type: integer; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Account identifier.

Example: `3`

Validation: JSON integer.

### data.accounts[].bank_name

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Bank or financial institution name.

Example: `Vietcombank`

Validation: JSON string.

### data.accounts[].account_type

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Account type.

Example: `Checking`

Allowed values: Checking; Credit Card; Savings; Investment; Loan

Validation: Member of the declared public enum.

### data.accounts[].branch_name

Type: string; Required: Yes; Nullable: Yes

Trigger: Response containing this field.

Description: Branch name.

Example: `Hanoi Branch`

Validation: JSON string.

### data.accounts[].account_number_last_4

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Last four digits of the account number.

Example: `0123`

Validation: JSON string.

### data.accounts[].balance

Type: number; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Current account balance.

Example: `4500000`

Validation: JSON number.

### data.accounts[].version

Type: integer; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Resource version.

Example: `1`

Validation: JSON integer.

## Error Response — HTTP 400

Public outcome: Malformed wire input or rejected operation.

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error outcome flag.

Example: `false`

Note: Not specified.

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable error message.

Example: `Request could not be completed`

Note: Not specified.

Validation: JSON string.

### error

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error payload.

Example: `{}`

Note: Not specified.

Validation: JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Public error code.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Allowed values: MALFORMED_REQUEST

Validation: Member of the declared public enum.

## Error Response — HTTP 401

Public outcome: Rejected authentication context.

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error outcome flag.

Example: `false`

Note: Not specified.

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable error message.

Example: `Request could not be completed`

Note: Not specified.

Validation: JSON string.

### error

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error payload.

Example: `{}`

Note: Not specified.

Validation: JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Public error code.

Example: `UNAUTHENTICATED`

Note: Not specified.

Allowed values: UNAUTHENTICATED

Validation: Member of the declared public enum.

## Error Response — HTTP 500

Public outcome: Temporary service failure.

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error outcome flag.

Example: `false`

Note: Not specified.

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable error message.

Example: `Request could not be completed`

Note: Not specified.

Validation: JSON string.

### error

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error payload.

Example: `{}`

Note: Not specified.

Validation: JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Public error code.

Example: `INTERNAL_ERROR`

Note: Not specified.

Allowed values: INTERNAL_ERROR

Validation: Member of the declared public enum.

## Notes

[Common wire contract](common-contract.md). Source: [API contract starting at row 39](https://docs.google.com/spreadsheets/d/1b6nG8slHLf2CtXZwVHHsNrogvhHNg3lceK6f3B7mKIM/edit#gid=439687549&range=A39:B55). These are reviewed contracts; compatibility changes are recorded in the package review. Child fields under a nullable object apply when that object is present.
