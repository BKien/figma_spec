---
artifact_type: api-contract
status: Frozen
api_id: API-AUTH-LOGIN
related_uc_id: UC-02
---

# API-AUTH-LOGIN: User Login

## General Information

### API ID

`API-AUTH-LOGIN`

### API Name

User Login

### Related Use Case IDs

`UC-02`

### Method

`POST`

### Path

`/api/auth/login`

### Description

Authenticate a registered user and issue a JWT access token.

### Authentication

Public.

### Authorization

None.

## Request Header(s)

### headers.Content-Type

Type: string; Format: Not specified.; Required: Yes; Nullable: No

Trigger: Request containing this field.

Description: Body media type.

Example: `application/json`

Note: Not specified.

Allowed values: application/json

Validation: Member of the declared public enum.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

### email

Type: string; Format: email; Required: Yes; Nullable: No

Trigger: Request containing this field.

Description: Registered email address.

Example: `user@example.com`

Validation: Email-address syntax.

### password

Type: string; Format: password; Required: Yes; Nullable: No

Trigger: Request containing this field.

Description: User password.

Example: `P@ssw0rd!`

Validation: Matches the declared JSON type.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Response outcome flag.

Example: `true`

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable response message.

Example: `Operation completed`

Validation: JSON string.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Operation payload.

Example: `{}`

Validation: JSON object.

### data.user

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Nested response object.

Example: `{}`

Validation: JSON object.

### data.accessToken

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: JWT access token.

Example: `eyJhbGciOiJIUzI1NiIs...`

Validation: JSON string.

### data.user.id

Type: integer; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Authenticated user identifier.

Example: `1`

Validation: JSON integer.

### data.user.fullName

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Authenticated user's full name.

Example: `John Doe`

Validation: JSON string.

### data.user.email

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Authenticated user's email address.

Example: `user@example.com`

Validation: JSON string.

## Error Response — HTTP 400

Public outcome: Malformed wire input or rejected operation.

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error outcome flag.

Example: `false`

Note: Not specified.

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable error message.

Example: `Request could not be completed`

Note: Not specified.

Validation: JSON string.

### error

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error payload.

Example: `{}`

Note: Not specified.

Validation: JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Public error code.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Allowed values: MALFORMED_REQUEST

Validation: Member of the declared public enum.

## Error Response — HTTP 401

Public outcome: Rejected authentication context.

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error outcome flag.

Example: `false`

Note: Not specified.

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable error message.

Example: `Request could not be completed`

Note: Not specified.

Validation: JSON string.

### error

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error payload.

Example: `{}`

Note: Not specified.

Validation: JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Public error code.

Example: `UNAUTHENTICATED`

Note: Not specified.

Allowed values: UNAUTHENTICATED

Validation: Member of the declared public enum.

## Error Response — HTTP 500

Public outcome: Temporary service failure.

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error outcome flag.

Example: `false`

Note: Not specified.

Validation: JSON boolean.

### message

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Human-readable error message.

Example: `Request could not be completed`

Note: Not specified.

Validation: JSON string.

### error

Type: object; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Error payload.

Example: `{}`

Note: Not specified.

Validation: JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Response containing this field.

Description: Public error code.

Example: `INTERNAL_ERROR`

Note: Not specified.

Allowed values: INTERNAL_ERROR

Validation: Member of the declared public enum.

## Notes

[Common wire contract](common-contract.md). Source: [API contract starting at row 3](https://docs.google.com/spreadsheets/d/1b6nG8slHLf2CtXZwVHHsNrogvhHNg3lceK6f3B7mKIM/edit#gid=439687549&range=A3:B19). These are reviewed contracts; compatibility changes are recorded in the package review. Child fields under a nullable object apply when that object is present.
