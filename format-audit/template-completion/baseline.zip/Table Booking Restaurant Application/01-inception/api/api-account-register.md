---
artifact_type: api-contract
status: Frozen
api_id: API-ACCOUNT-REGISTER
related_uc_id: UC-01
---

# API-ACCOUNT-REGISTER: Register an Account

## General Information

### API ID

`API-ACCOUNT-REGISTER`

### API Name

Register an Account

### Related Use Case IDs

- `UC-01`

### Method

`POST`

### Path

`/api/v1/accounts`

### Description

Accepts the displayed register an account interaction and returns its public result.

### Authentication

None.

### Authorization

Public endpoint.

## Request Header(s)

### headers.Content-Type

Type: string; Format: MIME type; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Declares the request media type.

Example: `application/json`

Note: Not specified.

Allowed values: application/json

Validation: Must identify the `application/json` media type.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

### email

Type: string; Format: email; Required: Yes; Nullable: No

Trigger: Not specified.

Description: email supplied on the wire.

Example: `alex@example.com`

Validation: Must use email-address syntax.

### password

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: password supplied on the wire.

Example: `ExamplePassphrase1!`

Validation: Must be encoded as a JSON string.

### displayName

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: displayName supplied on the wire.

Example: `Alex Morgan`

Validation: Must be encoded as a JSON string.

### agreementAccepted

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: agreementAccepted supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

## Success Response — HTTP 201

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: success supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data supplied on the wire.

Example: `{}`

Validation: Must be encoded as a JSON object.

### data.accountId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data accountId supplied on the wire.

Example: `acc_123`

Validation: Must be encoded as a JSON string.

### data.verificationRequired

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data verificationRequired supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 503

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `SERVICE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Temporary service failure.

Description: Human-readable error summary.

Example: `Please try again later.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 409

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Operation conflict response.

Description: Stable public error identifier.

Example: `OPERATION_CONFLICT`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

The common response envelope and pagination conventions are defined in [common-contract.md](common-contract.md). Business behavior is specified only in [UC-01](../uc/uc-01-register-account.md).
