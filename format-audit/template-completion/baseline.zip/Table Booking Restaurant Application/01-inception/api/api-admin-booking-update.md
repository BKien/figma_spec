---
artifact_type: api-contract
status: Frozen
api_id: API-ADMIN-BOOKING-UPDATE
related_uc_id: UC-16
---

# API-ADMIN-BOOKING-UPDATE: Update a Booking as Admin

## General Information

### API ID

`API-ADMIN-BOOKING-UPDATE`

### API Name

Update a Booking as Admin

### Related Use Case IDs

- `UC-16`

### Method

`PATCH`

### Path

`/api/v1/admin/bookings/{bookingId}`

### Description

Accepts the displayed update a booking as admin interaction and returns its public result.

### Authentication

Bearer access token.

### Authorization

Administration role.

## Request Header(s)

### headers.Authorization

Type: string; Format: bearer token; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Carries the bearer access token.

Example: `Bearer eyJ...`

Note: Not specified.

Validation: Must use the `Bearer <access-token>` header syntax.

### headers.Content-Type

Type: string; Format: MIME type; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Declares the request media type.

Example: `application/json`

Note: Not specified.

Allowed values: application/json

Validation: Must identify the `application/json` media type.

## Path Parameter(s)

### path.bookingId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: bookingId supplied on the wire.

Example: `bkg_123`

Validation: Must be encoded as one URL path segment.

## Query Parameter(s)

None.

## Request Body

### slotId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: slotId supplied on the wire.

Example: `slot_456`

Validation: Must be encoded as a JSON string.

### partySize

Type: integer; Required: Yes; Nullable: No

Trigger: Not specified.

Description: partySize supplied on the wire.

Example: `3`

Validation: Must be encoded as a JSON integer.

### version

Type: integer; Required: Yes; Nullable: No

Trigger: Not specified.

Description: version supplied on the wire.

Example: `2`

Validation: Must be encoded as a JSON integer.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: success supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data supplied on the wire.

Example: `{}`

Validation: Must be encoded as a JSON object.

### data.bookingId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data bookingId supplied on the wire.

Example: `bkg_123`

Validation: Must be encoded as a JSON string.

### data.version

Type: integer; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data version supplied on the wire.

Example: `3`

Validation: Must be encoded as a JSON integer.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 503

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `SERVICE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Temporary service failure.

Description: Human-readable error summary.

Example: `Please try again later.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 401

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Rejected authentication context.

Description: Stable public error identifier.

Example: `AUTHENTICATION_REQUIRED`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 403

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Access denied response.

Description: Stable public error identifier.

Example: `ACCESS_DENIED`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 404

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Unavailable resource response.

Description: Stable public error identifier.

Example: `RESOURCE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 409

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Operation conflict response.

Description: Stable public error identifier.

Example: `OPERATION_CONFLICT`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

The common response envelope and pagination conventions are defined in [common-contract.md](common-contract.md). Business behavior is specified only in [UC-16](../uc/uc-16-update-admin-booking.md).
