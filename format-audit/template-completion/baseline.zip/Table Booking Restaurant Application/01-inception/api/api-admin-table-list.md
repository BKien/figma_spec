---
artifact_type: api-contract
status: Frozen
api_id: API-ADMIN-TABLE-LIST
related_uc_id: UC-17
---

# API-ADMIN-TABLE-LIST: View Table Layout

## General Information

### API ID

`API-ADMIN-TABLE-LIST`

### API Name

View Table Layout

### Related Use Case IDs

- `UC-17`

### Method

`GET`

### Path

`/api/v1/admin/restaurants/{restaurantId}/tables`

### Description

Accepts the displayed view table layout interaction and returns its public result.

### Authentication

Bearer access token.

### Authorization

Administration role.

## Request Header(s)

### headers.Authorization

Type: string; Format: bearer token; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Carries the bearer access token.

Example: `Bearer eyJ...`

Note: Not specified.

Validation: Must use the `Bearer <access-token>` header syntax.

## Path Parameter(s)

### path.restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as one URL path segment.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: success supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data supplied on the wire.

Example: `{}`

Validation: Must be encoded as a JSON object.

### data.tables

Type: array; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data tables supplied on the wire.

Example: `[]`

Validation: Must be encoded as a JSON array.

### data.restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as a JSON string.

### data.tables[].id

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data tables[] id supplied on the wire.

Example: `tbl_123`

Validation: Must be encoded as a JSON string.

### data.tables[].label

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data tables[] label supplied on the wire.

Example: `T1`

Validation: Must be encoded as a JSON string.

### data.tables[].capacity

Type: integer; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data tables[] capacity supplied on the wire.

Example: `4`

Validation: Must be encoded as a JSON integer.

### data.tables[].layoutX

Type: number; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data tables[] layoutX supplied on the wire.

Example: `120`

Validation: Must be encoded as a JSON number.

### data.tables[].layoutY

Type: number; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data tables[] layoutY supplied on the wire.

Example: `80`

Validation: Must be encoded as a JSON number.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 503

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `SERVICE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Temporary service failure.

Description: Human-readable error summary.

Example: `Please try again later.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 401

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Rejected authentication context.

Description: Stable public error identifier.

Example: `AUTHENTICATION_REQUIRED`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 403

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Access denied response.

Description: Stable public error identifier.

Example: `ACCESS_DENIED`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 404

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Unavailable resource response.

Description: Stable public error identifier.

Example: `RESOURCE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

The common response envelope and pagination conventions are defined in [common-contract.md](common-contract.md). Business behavior is specified only in [UC-17](../uc/uc-17-view-table-layout.md).
