---
artifact_type: api-contract
status: Frozen
api_id: API-BOOKING-CREATE
related_uc_id: UC-08
---

# API-BOOKING-CREATE: Book a Table

## General Information

### API ID

`API-BOOKING-CREATE`

### API Name

Book a Table

### Related Use Case IDs

- `UC-08`

### Method

`POST`

### Path

`/api/v1/bookings`

### Description

Accepts the displayed book a table interaction and returns its public result.

### Authentication

Bearer access token.

### Authorization

Authenticated customer.

## Request Header(s)

### headers.Authorization

Type: string; Format: bearer token; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Carries the bearer access token.

Example: `Bearer eyJ...`

Note: Not specified.

Validation: Must use the `Bearer <access-token>` header syntax.

### headers.Content-Type

Type: string; Format: MIME type; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Declares the request media type.

Example: `application/json`

Note: Not specified.

Allowed values: application/json

Validation: Must identify the `application/json` media type.

### headers.Idempotency-Key

Type: string; Format: HTTP header; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Carries a client-generated operation key.

Example: `booking-7e6f`

Note: Not specified.

Validation: Must be encoded as an HTTP header value.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

### restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as a JSON string.

### slotId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: slotId supplied on the wire.

Example: `slot_123`

Validation: Must be encoded as a JSON string.

### partySize

Type: integer; Required: Yes; Nullable: No

Trigger: Not specified.

Description: partySize supplied on the wire.

Example: `2`

Validation: Must be encoded as a JSON integer.

### contactPhone

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: contactPhone supplied on the wire.

Example: `+12025550123`

Validation: Must be encoded as a JSON string.

### verificationCode

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: verificationCode supplied on the wire.

Example: `123456`

Validation: Must be encoded as a JSON string.

## Success Response — HTTP 201

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: success supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data supplied on the wire.

Example: `{}`

Validation: Must be encoded as a JSON object.

### data.bookingId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data bookingId supplied on the wire.

Example: `bkg_123`

Validation: Must be encoded as a JSON string.

### data.status

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data status supplied on the wire.

Example: `CONFIRMED`

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 503

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `SERVICE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Temporary service failure.

Description: Human-readable error summary.

Example: `Please try again later.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 401

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Rejected authentication context.

Description: Stable public error identifier.

Example: `AUTHENTICATION_REQUIRED`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 409

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Operation conflict response.

Description: Stable public error identifier.

Example: `OPERATION_CONFLICT`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

The common response envelope and pagination conventions are defined in [common-contract.md](common-contract.md). Business behavior is specified only in [UC-08](../uc/uc-08-book-table.md).
