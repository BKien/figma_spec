---
artifact_type: api-contract
status: Frozen
api_id: API-MENU-LIST
related_uc_id: UC-06
---

# API-MENU-LIST: View a Restaurant Menu

## General Information

### API ID

`API-MENU-LIST`

### API Name

View a Restaurant Menu

### Related Use Case IDs

- `UC-06`

### Method

`GET`

### Path

`/api/v1/restaurants/{restaurantId}/menu`

### Description

Accepts the displayed view a restaurant menu interaction and returns its public result.

### Authentication

None.

### Authorization

Public endpoint.

## Request Header(s)

None.

## Path Parameter(s)

### path.restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as one URL path segment.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: success supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data supplied on the wire.

Example: `{}`

Validation: Must be encoded as a JSON object.

### data.items

Type: array; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data items supplied on the wire.

Example: `[]`

Validation: Must be encoded as a JSON array.

### data.restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as a JSON string.

### data.items[].id

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data items[] id supplied on the wire.

Example: `itm_123`

Validation: Must be encoded as a JSON string.

### data.items[].name

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data items[] name supplied on the wire.

Example: `Pasta`

Validation: Must be encoded as a JSON string.

### data.items[].sectionName

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data items[] sectionName supplied on the wire.

Example: `Mains`

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 503

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `SERVICE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Temporary service failure.

Description: Human-readable error summary.

Example: `Please try again later.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 404

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Unavailable resource response.

Description: Stable public error identifier.

Example: `RESOURCE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

The common response envelope and pagination conventions are defined in [common-contract.md](common-contract.md). Business behavior is specified only in [UC-06](../uc/uc-06-view-menu.md).
