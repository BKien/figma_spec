---
artifact_type: api-contract
status: Frozen
api_id: API-RESTAURANT-DETAIL
related_uc_id: UC-05
---

# API-RESTAURANT-DETAIL: View Restaurant Details

## General Information

### API ID

`API-RESTAURANT-DETAIL`

### API Name

View Restaurant Details

### Related Use Case IDs

- `UC-05`

### Method

`GET`

### Path

`/api/v1/restaurants/{restaurantId}`

### Description

Accepts the displayed view restaurant details interaction and returns its public result.

### Authentication

None.

### Authorization

Public endpoint.

## Request Header(s)

None.

## Path Parameter(s)

### path.restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as one URL path segment.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: success supplied on the wire.

Example: `true`

Validation: Must be encoded as a JSON boolean.

### data

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data supplied on the wire.

Example: `{}`

Validation: Must be encoded as a JSON object.

### data.restaurantId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data restaurantId supplied on the wire.

Example: `rst_123`

Validation: Must be encoded as a JSON string.

### data.name

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data name supplied on the wire.

Example: `Villagio Restaurant and Bar`

Validation: Must be encoded as a JSON string.

### data.address

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data address supplied on the wire.

Example: `Miami, FL`

Validation: Must be encoded as a JSON string.

### data.cuisine

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data cuisine supplied on the wire.

Example: `Italian`

Validation: Must be encoded as a JSON string.

### data.rating

Type: number; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data rating supplied on the wire.

Example: `4.5`

Validation: Must be encoded as a JSON number.

### data.photos

Type: array; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data photos supplied on the wire.

Example: `[]`

Validation: Must be encoded as a JSON array.

### data.photos[]

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: data photos[] supplied on the wire.

Example: `https://example.com/dining-room.jpg`

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 400

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `MALFORMED_REQUEST`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Malformed wire input.

Description: Human-readable error summary.

Example: `The request could not be processed.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 503

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Stable public error identifier.

Example: `SERVICE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

### error.message

Type: string; Required: Yes; Nullable: No

Trigger: Temporary service failure.

Description: Human-readable error summary.

Example: `Please try again later.`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Error Response — HTTP 404

### error

Type: object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: error supplied on the wire.

Example: `{}`

Note: Not specified.

Validation: Must be encoded as a JSON object.

### error.code

Type: string; Required: Yes; Nullable: No

Trigger: Unavailable resource response.

Description: Stable public error identifier.

Example: `RESOURCE_UNAVAILABLE`

Note: Not specified.

Validation: Must be encoded as a JSON string.

## Notes

The common response envelope and pagination conventions are defined in [common-contract.md](common-contract.md). Business behavior is specified only in [UC-05](../uc/uc-05-view-restaurant.md).
