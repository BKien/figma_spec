---
artifact_type: api-contract
status: Frozen
api_id: API-BUDGET-TRIP-DETAIL
related_uc_id: UC-17
---

# API-BUDGET-TRIP-DETAIL: Get Budget Trip Details

## General Information

### API ID

`API-BUDGET-TRIP-DETAIL`

### API Name

Budget Trip Details

### Related Use Case IDs

- `UC-17`

### Method

`GET`

### Path

`/api/v1/budget-trips/{tripId}`

### Description

Returns destination, description, attraction, media, and price data for one budget trip.

### Authentication

Public

### Authorization

None

## Request Header(s)

None.

## Path Parameter(s)

### path.tripId

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Opaque budget-trip identifier.

Example: `trip_01JABCDEF`

Validation: Must be encoded as one path segment.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Not specified.

Example: `true`

### message

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Not specified.

Example: `Budget trip details retrieved.`

### data.id

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Budget-trip identifier.

Example: Not specified.

### data.title

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Display title.

Example: Not specified.

### data.description

Type: string; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Descriptive content.

Example: Not specified.

### data.destination

Type: object; Required: Yes; Nullable: No
- Fields: `id` (string), `name` (string), `countryCode` (string).

Trigger: Not specified.

Description: Destination data returned for display.

Example: Not specified.

### data.attractions

Type: string array; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Attraction labels.

Example: Not specified.

### data.imageUrls

Type: URI string array; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Media URLs.

Example: Not specified.

### data.startingPrice

Type: money object; Required: Yes; Nullable: No

Trigger: Not specified.

Description: Display starting price.

Example: Not specified.

## Error Response — HTTP 404

- Code: `BUDGET_TRIP_NOT_FOUND`
Trigger: The requested budget trip cannot be returned.
Description: Public not-found response.
- Example message: `The requested budget trip was not found.`

## Error Response — HTTP 500

- Code: `INTERNAL_ERROR`
Trigger: An unexpected server error prevents details from being returned.
Description: Unexpected trip-service failure.
- Example message: `Internal Server Error`

## Notes

Response envelopes, money values, and nested-field conventions follow the [common API contract](common-contract.md).

The response contains display-ready data only.
