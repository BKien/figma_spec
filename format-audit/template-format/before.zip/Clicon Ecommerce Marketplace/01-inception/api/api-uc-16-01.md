---
artifact_type: api-contract
status: Draft
api_id: API-UC-16-01
related_uc_id: UC-16
---

# API-UC-16-01: GET /api/v1/account/orders/:orderId

## General Information

### API ID

`API-UC-16-01`

### API Name

View Order Details — GET /api/v1/account/orders/:orderId

### Related Use Case IDs

- `UC-16`

### Method

`GET`

### Path

`/api/v1/account/orders/:orderId`

### Description

Provides the wire operation referenced by the supplied View Order Details specification.

### Authentication

Authentication context is supplied when required by the preserved source contract.

### Authorization

The service evaluates the submitted operation context.

## Request Header(s)

None.

## Path Parameter(s)

### orderId

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as an opaque path string.
Description: Identifies the requested path resource on the wire.
Example: `example-orderId`

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON boolean.
Description: Indicates a successful protocol outcome.
Example: `true`

### data

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Contains the operation-specific response fields defined by the preserved source contract.
Example: `{}`

## Error Response — HTTP 400

### error

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Contains the public protocol error.
Example: `{}`

### error.code

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON string.
Description: Stable public error identifier.
Example: `MALFORMED_REQUEST`

### error.message

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON string.
Description: Human-readable public error summary.
Example: `The request could not be processed.`

Trigger: Malformed wire input.

## Notes

Detailed endpoint fields, status codes, examples, and public outcomes are preserved in [the supplied source](../../source/clicon-uc-16-view-order-details.md). Business behavior is specified by [UC-16](../uc/uc-16-view-order-details.md).
