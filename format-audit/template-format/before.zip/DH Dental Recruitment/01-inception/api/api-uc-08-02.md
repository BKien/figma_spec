---
artifact_type: api-contract
status: Draft
api_id: API-UC-08-02
related_uc_id: UC-08
---

# API-UC-08-02: PUT /api/v1/job-seeker/profile/work-experience

## General Information

### API ID

`API-UC-08-02`

### API Name

Manage Work Experience and Resume — PUT /api/v1/job-seeker/profile/work-experience

### Related Use Case IDs

- `UC-08`

### Method

`PUT`

### Path

`/api/v1/job-seeker/profile/work-experience`

### Description

Provides the wire operation referenced by the supplied Manage Work Experience and Resume specification.

### Authentication

Authentication context is supplied when required by the preserved source contract.

### Authorization

The service evaluates the submitted operation context.

## Request Header(s)

### Content-Type

Type: string
Format: MIME type
Required: Yes
Nullable: No
Allowed values: application/json
Validation: Must identify the `application/json` media type.
Description: Declares the request representation.
Example: `application/json`

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

### payload

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Carries the operation-specific request fields defined by the preserved source contract.
Example: `{}`

## Success Response — HTTP 200

### success

Type: boolean
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON boolean.
Description: Indicates a successful protocol outcome.
Example: `true`

### data

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Contains the operation-specific response fields defined by the preserved source contract.
Example: `{}`

## Error Response — HTTP 400

### error

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Contains the public protocol error.
Example: `{}`

### error.code

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON string.
Description: Stable public error identifier.
Example: `MALFORMED_REQUEST`

### error.message

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON string.
Description: Human-readable public error summary.
Example: `The request could not be processed.`

Trigger: Malformed wire input.

## Notes

Detailed endpoint fields, status codes, examples, and public outcomes are preserved in [the supplied source](../../source/dh-dental-uc-08-manage-work-experience.md). Business behavior is specified by [UC-08](../uc/uc-08-manage-work-experience.md).
