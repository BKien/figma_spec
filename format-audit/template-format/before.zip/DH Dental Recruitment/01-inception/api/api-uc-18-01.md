---
artifact_type: api-contract
status: Draft
api_id: API-UC-18-01
related_uc_id: UC-18
---

# API-UC-18-01: GET /api/v1/candidate-profiles

## General Information

### API ID

`API-UC-18-01`

### API Name

Search and Filter Public Candidate Profiles — GET /api/v1/candidate-profiles

### Related Use Case IDs

- `UC-18`

### Method

`GET`

### Path

`/api/v1/candidate-profiles`

### Description

Provides the wire operation referenced by the supplied Search and Filter Public Candidate Profiles specification.

### Authentication

Authentication context is supplied when required by the preserved source contract.

### Authorization

The service evaluates the submitted operation context.

## Request Header(s)

None.

## Path Parameter(s)

None.

## Query Parameter(s)

None.

## Request Body

None.

## Success Response — HTTP 200

### success

Type: boolean
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON boolean.
Description: Indicates a successful protocol outcome.
Example: `true`

### data

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Contains the operation-specific response fields defined by the preserved source contract.
Example: `{}`

## Error Response — HTTP 400

### error

Type: object
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON object.
Description: Contains the public protocol error.
Example: `{}`

### error.code

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON string.
Description: Stable public error identifier.
Example: `MALFORMED_REQUEST`

### error.message

Type: string
Required: Yes
Nullable: No
Validation: Must be encoded as a JSON string.
Description: Human-readable public error summary.
Example: `The request could not be processed.`

Trigger: Malformed wire input.

## Notes

Detailed endpoint fields, status codes, examples, and public outcomes are preserved in [the supplied source](../../source/dh-dental-uc-18-search-public-profiles.md). Business behavior is specified by [UC-18](../uc/uc-18-search-public-profiles.md).
