# API-SESSION-DEPARTURE — Leave or End a Session

## API ID

`API-SESSION-DEPARTURE`

## API Name

Leave or End a Session

## Related Use Case IDs

- `UC-17`
- `UC-18`

## Method

`POST`

## Path

`/api/v1/sessions/{sessionId}/departure-commands`

## Description

Returns the departure and session representations.

## Authentication

Bearer session access token, using the registered or guest form described in the common contract.

## Authorization

Required.

## Request Headers

### `Authorization`

- Type: string
- Required: Yes
- Nullable: No
- Description: Bearer session access token.
- Example: `Bearer <session-access-token>`

### `Content-Type`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: `application/json`
- Description: HTTP media-type header.
- Example: `application/json`

### `Idempotency-Key`

- Type: string
- Required: Yes
- Nullable: No
- Description: Opaque HTTP command token.
- Example: `command-22-01`

## Path Parameters

### `sessionId`

- Type: string
- Required: Yes
- Nullable: No
- Description: UUID identifier.
- Example: `11111111-1111-4111-8111-111111111111`

## Query Parameters

None.

## Request Body

### `kind`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: `LEAVE`, `END`
- Validation: Must be a JSON string. String values must belong to the declared enum.
- Description: kind value.
- Example: `LEAVE`

### `expectedVersion`

- Type: integer
- Required: Yes
- Nullable: No
- Validation: Must be a JSON integer.
- Description: expectedVersion value.
- Example: `1`

## Success Response — HTTP 200

Inherits the success envelope and named object definitions in [Common Contract](common-contract.md).

### `data.departure`

- Type: object (Departure)
- Required: Yes
- Nullable: No
- Description: Representation defined in the common contract.

### `data.session`

- Type: object (SessionSummary)
- Required: Yes
- Nullable: No
- Description: Representation defined in the common contract.

### `data.participant`

- Type: object (Participant)
- Required: Yes
- Nullable: No
- Description: Representation defined in the common contract.

## Error Response — HTTP 400

- Code: `INVALID_REQUEST`
- Trigger: The request cannot be decoded or does not match the declared wire schema.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Error Response — HTTP 401

- Code: `AUTHENTICATION_REJECTED`
- Trigger: The authentication context is rejected.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Error Response — HTTP 403

- Code: `ACCESS_REJECTED`
- Trigger: The operation is rejected for the supplied access context.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Error Response — HTTP 404

- Code: `RESOURCE_UNAVAILABLE`
- Trigger: The requested resource is unavailable.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Error Response — HTTP 409

- Code: `OPERATION_CONFLICT`
- Trigger: The operation conflicts with the current resource response.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Error Response — HTTP 422

- Code: `COMMAND_REJECTED`
- Trigger: The submitted command is rejected.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Error Response — HTTP 503

- Code: `SERVICE_UNAVAILABLE`
- Trigger: A required service is temporarily unavailable.
- Description: Uses the common error envelope.
- Example message: `The request could not be completed.`

## Notes

This endpoint inherits [Common Contract](common-contract.md).
