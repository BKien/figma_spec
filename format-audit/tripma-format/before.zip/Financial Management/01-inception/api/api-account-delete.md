# API-ACCOUNT-DELETE — Delete Bank Account

## API ID

`API-ACCOUNT-DELETE`

## API Name

Delete Bank Account

## Related Use Case IDs

`UC-09`

## Method

`DELETE`

## Path

`/api/v1/accounts/{id}`

## Description

Delete an owned account and all transactions related to it.

## Authentication

Bearer JWT in the Authorization header.

## Authorization

Authenticated request context.

## Request Headers

### `Authorization`

- Type: string
- Required: Yes
- Nullable: No
- Validation: Matches the declared JSON type.
- Trigger: Request containing this field.
- Description: Bearer authentication header.
- Example: `Bearer <access-token>`

### `If-Match`

- Type: string
- Format: Quoted integer ETag
- Required: Yes
- Nullable: No
- Validation: Matches the declared JSON type.
- Trigger: Request containing this field.
- Description: Resource version representation.
- Example: `"1"`

## Path Parameters

### `path.id`

- Type: integer
- Required: Yes
- Nullable: No
- Validation: JSON integer; query and path values use complete decimal text.
- Trigger: Request containing this field.
- Description: Account identifier.
- Example: `3`

## Query Parameters

None.

## Request Body

None.

## Success Response — HTTP 200

### `success`

- Type: boolean
- Required: Yes
- Nullable: No
- Validation: JSON boolean.
- Trigger: Response containing this field.
- Description: Response outcome flag.
- Example: `true`

### `message`

- Type: string
- Required: Yes
- Nullable: No
- Validation: JSON string.
- Trigger: Response containing this field.
- Description: Human-readable response message.
- Example: `Operation completed`

### `data`

- Type: object
- Required: Yes
- Nullable: No
- Validation: JSON object.
- Trigger: Response containing this field.
- Description: Operation payload.
- Example: `{}`

### `data.deleted_account_id`

- Type: integer
- Required: Yes
- Nullable: No
- Validation: JSON integer.
- Trigger: Response containing this field.
- Description: Deleted account identifier.
- Example: `3`

## Error Response — HTTP 400

Public outcome: Malformed wire input or rejected operation.

### `success`

- Type: boolean
- Required: Yes
- Nullable: No
- Validation: JSON boolean.
- Trigger: Response containing this field.
- Description: Error outcome flag.
- Example: `false`

### `message`

- Type: string
- Required: Yes
- Nullable: No
- Validation: JSON string.
- Trigger: Response containing this field.
- Description: Human-readable error message.
- Example: `Request could not be completed`

### `error`

- Type: object
- Required: Yes
- Nullable: No
- Validation: JSON object.
- Trigger: Response containing this field.
- Description: Error payload.
- Example: `{}`

### `error.code`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: MALFORMED_REQUEST
- Validation: Member of the declared public enum.
- Trigger: Response containing this field.
- Description: Public error code.
- Example: `MALFORMED_REQUEST`

## Error Response — HTTP 401

Public outcome: Rejected authentication context.

### `success`

- Type: boolean
- Required: Yes
- Nullable: No
- Validation: JSON boolean.
- Trigger: Response containing this field.
- Description: Error outcome flag.
- Example: `false`

### `message`

- Type: string
- Required: Yes
- Nullable: No
- Validation: JSON string.
- Trigger: Response containing this field.
- Description: Human-readable error message.
- Example: `Request could not be completed`

### `error`

- Type: object
- Required: Yes
- Nullable: No
- Validation: JSON object.
- Trigger: Response containing this field.
- Description: Error payload.
- Example: `{}`

### `error.code`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: UNAUTHENTICATED
- Validation: Member of the declared public enum.
- Trigger: Response containing this field.
- Description: Public error code.
- Example: `UNAUTHENTICATED`

## Error Response — HTTP 404

Public outcome: Unavailable resource response.

### `success`

- Type: boolean
- Required: Yes
- Nullable: No
- Validation: JSON boolean.
- Trigger: Response containing this field.
- Description: Error outcome flag.
- Example: `false`

### `message`

- Type: string
- Required: Yes
- Nullable: No
- Validation: JSON string.
- Trigger: Response containing this field.
- Description: Human-readable error message.
- Example: `Request could not be completed`

### `error`

- Type: object
- Required: Yes
- Nullable: No
- Validation: JSON object.
- Trigger: Response containing this field.
- Description: Error payload.
- Example: `{}`

### `error.code`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: NOT_FOUND
- Validation: Member of the declared public enum.
- Trigger: Response containing this field.
- Description: Public error code.
- Example: `NOT_FOUND`

## Error Response — HTTP 409

Public outcome: Operation conflict.

### `success`

- Type: boolean
- Required: Yes
- Nullable: No
- Validation: JSON boolean.
- Trigger: Response containing this field.
- Description: Error outcome flag.
- Example: `false`

### `message`

- Type: string
- Required: Yes
- Nullable: No
- Validation: JSON string.
- Trigger: Response containing this field.
- Description: Human-readable error message.
- Example: `Request could not be completed`

### `error`

- Type: object
- Required: Yes
- Nullable: No
- Validation: JSON object.
- Trigger: Response containing this field.
- Description: Error payload.
- Example: `{}`

### `error.code`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: OPERATION_CONFLICT
- Validation: Member of the declared public enum.
- Trigger: Response containing this field.
- Description: Public error code.
- Example: `OPERATION_CONFLICT`

## Error Response — HTTP 500

Public outcome: Temporary service failure.

### `success`

- Type: boolean
- Required: Yes
- Nullable: No
- Validation: JSON boolean.
- Trigger: Response containing this field.
- Description: Error outcome flag.
- Example: `false`

### `message`

- Type: string
- Required: Yes
- Nullable: No
- Validation: JSON string.
- Trigger: Response containing this field.
- Description: Human-readable error message.
- Example: `Request could not be completed`

### `error`

- Type: object
- Required: Yes
- Nullable: No
- Validation: JSON object.
- Trigger: Response containing this field.
- Description: Error payload.
- Example: `{}`

### `error.code`

- Type: string
- Required: Yes
- Nullable: No
- Allowed values: INTERNAL_ERROR
- Validation: Member of the declared public enum.
- Trigger: Response containing this field.
- Description: Public error code.
- Example: `INTERNAL_ERROR`

## Notes

[Common wire contract](common-contract.md). Source: [API contract starting at row 116](https://docs.google.com/spreadsheets/d/1b6nG8slHLf2CtXZwVHHsNrogvhHNg3lceK6f3B7mKIM/edit#gid=439687549&range=A116:B132). These are reviewed contracts; compatibility changes are recorded in the package review. Child fields under a nullable object apply when that object is present.
