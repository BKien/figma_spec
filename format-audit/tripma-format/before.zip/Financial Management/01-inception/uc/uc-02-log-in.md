# UC-02 — Log In

### Description

Enter the application with an existing identity.

### Actors

Primary: Visitor. Supporting: application client and application service.

### Priority

High.

### Trigger

**TRG-UC-02-01** — The visitor opens the login page.

### Preconditions

- **PRE-UC-02-01** — The application view is open in the client.

### Postconditions

- **POST-UC-02-01** — On success, the client opens the home page with the returned user session.
- **POST-UC-02-02** — On failure, the client displays a recovery message in the current view.

### Basic Flow

1. The visitor opens the login page.
2. The client displays the login form.
3. The visitor enters email and password.
4. The visitor submits the form.
5. The client sends the login request.
6. The system returns the session result.
7. The client opens the home page.

### Alternative Flows

#### AF-UC-02-01

1. The visitor selects Create an account.
2. The client opens the registration page.

### Exception Flows

#### EF-UC-02-01

1. The system returns an operation error.
2. The client displays the error message and keeps the current view open.
3. The actor revises the interaction or retries the request.

### UML Model

```plantuml
@startuml
hide empty members
class AuthClient {
  +establish(response: AuthResult): ClientSession
}
class AuthResult {
  +success: Boolean
  +evaluated: Boolean
  +user: PublicUser [0..1]
  +accessToken: String [0..1]
  +secretFields: Set(String)
  +loggedFields: Set(String)
}
class AuthService {
  +login(ctx: RequestContext, cmd: LoginCommand): AuthResult
}
class CalendarDate {
  +year: Integer
  +month: Integer
  +ordinal: Integer
  +{static} parse(text: String): CalendarDate
  +{static} monthStart(date: CalendarDate): CalendarDate
  +{static} monthEnd(date: CalendarDate): CalendarDate
  +{static} previousMonth(date: CalendarDate): CalendarDate
}
class ClientSession {
  +accessToken: String [0..1]
  +user: PublicUser [0..1]
  +storage: String
  +durableFields: Set(String)
}
class LoginCommand {
  +email: String
  +password: String
}
class PasswordHasher {
  +{static} matches(password: String, hash: String): Boolean
  +{static} cost(hash: String): Integer
}
class PublicUser {
  +id: Integer
  +fullName: String
  +email: String
}
class RequestContext {
  +userId: Integer
  +authenticated: Boolean
  +today: CalendarDate
  +now: String
}
class Text {
  +{static} trim(s: String): String
  +{static} nfc(s: String): String
  +{static} lower(s: String): String
  +{static} matches(s: String, pattern: String): Boolean
  +{static} email(s: String): Boolean
  +{static} last4(s: String): String
  +{static} username(email: String, taken: Set(String)): String
}
class User {
  +id: Integer
  +fullName: String
  +email: String
  +username: String
  +passwordHash: String
  +version: Integer
}
AuthResult --> PublicUser : user
ClientSession --> PublicUser : user
RequestContext --> CalendarDate : today
note "CalendarDate.ordinal is the calendar-day index in Asia/Saigon.\nReal values denote exact decimals.\nSnapshot tuples compare complete persistent values." as Semantics
@enduml
```

### Business Rules

```ocl
-- BR-UC-02-01
-- Source: Product source
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
pre BR_UC_02_01_Email:
  Text::email(Text::lower(Text::trim(cmd.email)))
```

```ocl
-- BR-UC-02-02
-- Source: Product source
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
pre BR_UC_02_02_PasswordPresent:
  cmd.password.size() > 0
```

```ocl
-- BR-UC-02-03
-- Source: Product source
-- evaluated distinguishes a completed credential evaluation from infrastructure failure; it is internal and not a wire field.
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
post BR_UC_02_03_Credentials:
  result.evaluated implies result.success = User.allInstances()->exists(u | u.email = Text::lower(Text::trim(cmd.email)) and PasswordHasher::matches(cmd.password, u.passwordHash))
```

```ocl
-- BR-UC-02-04
-- Source: Product source
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
post BR_UC_02_04_CorrectIdentity:
  result.success implies User.allInstances()->exists(u | u.id = result.user.id and u.email = Text::lower(Text::trim(cmd.email)) and u.email = result.user.email and u.fullName = result.user.fullName)
```

```ocl
-- BR-UC-02-05
-- Source: Product source
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
post BR_UC_02_05_SessionIssued:
  result.success implies not result.accessToken.oclIsUndefined() and result.accessToken.size() > 0
```

```ocl
-- BR-UC-02-06
-- Source: Product source
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
post BR_UC_02_06_FailureSession:
  not result.success implies result.accessToken.oclIsUndefined() and result.user.oclIsUndefined()
```

```ocl
-- BR-UC-02-07
-- Source: Product source
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
post BR_UC_02_07_NoSecrets:
  result.secretFields->intersection(Set{'password','passwordHash'})->isEmpty() and result.loggedFields->intersection(Set{'password','passwordHash','accessToken'})->isEmpty()
```

```ocl
-- BR-UC-02-08
-- Source: Product source
-- Equality denotes the complete persistent value snapshot, including every property, not object identity alone.
context AuthService::login(ctx: RequestContext, cmd: LoginCommand): AuthResult
post BR_UC_02_08_UserUnchanged:
  User.allInstances()->collect(e | Tuple{id = e.id, fullName = e.fullName, email = e.email, username = e.username, passwordHash = e.passwordHash, version = e.version})->asSet() = User.allInstances()@pre->collect(e | Tuple{id = e.id@pre, fullName = e.fullName@pre, email = e.email@pre, username = e.username@pre, passwordHash = e.passwordHash@pre, version = e.version@pre})->asSet()
```

```ocl
-- BR-UC-02-09
-- Source: Assumption
context AuthClient::establish(response: AuthResult): ClientSession
post BR_UC_02_09_MemorySession:
  response.success implies result.accessToken = response.accessToken and result.user = response.user and result.storage = 'Memory' and result.durableFields->intersection(Set{'accessToken','password','passwordHash'})->isEmpty()
```

### Related UI

- Product-source UI descriptions: [Use cases rows 26-43](https://docs.google.com/spreadsheets/d/1b6nG8slHLf2CtXZwVHHsNrogvhHNg3lceK6f3B7mKIM/edit#gid=0&range=A26:B43). No Figma node identifier was supplied.

### Related APIs

- [API-AUTH-LOGIN](../api/api-auth-login.md)

### Notes

See [source mapping](../../coverage-report.md), [review decisions](../../consistency-review.md), and [assumptions](../../ASSUMPTIONS.md). The supplied spreadsheet is specification evidence; no running application or Figma interaction was verified.
