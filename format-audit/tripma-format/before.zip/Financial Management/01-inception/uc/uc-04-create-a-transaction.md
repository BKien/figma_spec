# UC-04 — Create a Transaction

### Description

Record income or an expense against a financial account.

### Actors

Primary: Account holder. Supporting: application client and application service.

### Priority

High.

### Trigger

**TRG-UC-04-01** — The user opens the Add Transaction form.

### Preconditions

- **PRE-UC-04-01** — The application view is open in the client.

### Postconditions

- **POST-UC-04-01** — On success, the client displays transaction confirmation and opens history.
- **POST-UC-04-02** — On failure, the client displays a recovery message in the current view.

### Basic Flow

1. The user opens the Add Transaction form.
2. The client requests accounts and categories.
3. The system returns the form choices.
4. The user enters transaction details and submits the form.
5. The client sends the transaction request.
6. The system returns the creation result.
7. The client displays confirmation and opens transaction history.

### Alternative Flows

#### AF-UC-04-01

1. The user leaves the category selection empty.
2. The client submits the form and displays the returned result.

### Exception Flows

#### EF-UC-04-01

1. The system returns an operation error.
2. The client displays the error message and keeps the current view open.
3. The actor revises the interaction or retries the request.

#### EF-UC-04-02

1. The system returns a rejected authentication context.
2. The client presents the login entry point.

#### EF-UC-04-03

1. The system returns an operation conflict.
2. The client offers to reload the current resource.
3. The user reloads the view and submits the interaction again.

### UML Model

```plantuml
@startuml
hide empty members
class Account {
  +id: Integer
  +userId: Integer
  +bankName: String
  +accountType: AccountType
  +branchName: String [0..1]
  +numberCiphertext: String
  +numberFingerprint: String
  +last4: String
  +balance: Real
  +version: Integer
  +createdAt: String
}
enum AccountType {
  Checking
  Credit_Card
  Savings
  Investment
  Loan
}
class CalendarDate {
  +year: Integer
  +month: Integer
  +ordinal: Integer
  +{static} parse(text: String): CalendarDate
  +{static} monthStart(date: CalendarDate): CalendarDate
  +{static} monthEnd(date: CalendarDate): CalendarDate
  +{static} previousMonth(date: CalendarDate): CalendarDate
}
class Category {
  +id: Integer
  +name: String
}
class CreateTransactionCommand {
  +accountId: Integer
  +categoryId: Integer [0..1]
  +date: CalendarDate
  +type: TransactionType
  +status: TransactionStatus
  +description: String
  +shopName: String
  +paymentMethod: String
  +amount: Real
  +expectedVersion: Integer
}
class Numeric {
  +{static} round2(x: Real): Real
  +{static} finite(x: Real): Boolean
  +{static} scale(x: Real): Integer
}
class RequestContext {
  +userId: Integer
  +authenticated: Boolean
  +today: CalendarDate
  +now: String
}
class Text {
  +{static} trim(s: String): String
  +{static} nfc(s: String): String
  +{static} lower(s: String): String
  +{static} matches(s: String, pattern: String): Boolean
  +{static} email(s: String): Boolean
  +{static} last4(s: String): String
  +{static} username(email: String, taken: Set(String)): String
}
class Transaction {
  +id: Integer
  +accountId: Integer
  +categoryId: Integer [0..1]
  +date: CalendarDate
  +type: TransactionType
  +status: TransactionStatus
  +description: String
  +shopName: String
  +paymentMethod: String
  +amount: Real
  +receiptId: String [0..1]
  +createdAt: String
}
class TransactionResult {
  +success: Boolean
  +transaction: Transaction [0..1]
}
class TransactionService {
  +create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
}
enum TransactionStatus {
  Complete
  Pending
  Failed
}
enum TransactionType {
  Revenue
  Expense
}
class User {
  +id: Integer
  +fullName: String
  +email: String
  +username: String
  +passwordHash: String
  +version: Integer
}
Account --> AccountType : accountType
CreateTransactionCommand --> CalendarDate : date
CreateTransactionCommand --> TransactionType : type
CreateTransactionCommand --> TransactionStatus : status
RequestContext --> CalendarDate : today
Transaction --> CalendarDate : date
Transaction --> TransactionType : type
Transaction --> TransactionStatus : status
TransactionResult --> Transaction : transaction
Account --> User : userId
Transaction --> Account : accountId
Transaction --> Category : categoryId
note "CalendarDate.ordinal is the calendar-day index in Asia/Saigon.\nReal values denote exact decimals.\nSnapshot tuples compare complete persistent values." as Semantics
@enduml
```

### Business Rules

```ocl
-- BR-UC-04-01
-- Source: Product source
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_01_AuthenticatedContext:
  ctx.authenticated and User.allInstances()->exists(u | u.id = ctx.userId)
```

```ocl
-- BR-UC-04-02
-- Source: Product source
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_02_OwnedAccount:
  Account.allInstances()->exists(a | a.id = cmd.accountId and a.userId = ctx.userId)
```

```ocl
-- BR-UC-04-03
-- Source: Assumption
-- Exact decimal arithmetic; upper bound matches DECIMAL(18,2). Source positivity and precision are retained.
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_03_ExactAmount:
  Numeric::finite(cmd.amount) and cmd.amount > 0 and Numeric::scale(cmd.amount) <= 2 and cmd.amount < 10000000000000000
```

```ocl
-- BR-UC-04-04
-- Source: Assumption
-- A future dated entry may be Pending/Failed; a realized cash flow cannot be future dated in this manually tracked ledger.
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_04_CompletedDate:
  cmd.status = TransactionStatus::Complete implies cmd.date.ordinal <= ctx.today.ordinal
```

```ocl
-- BR-UC-04-05
-- Source: Assumption
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_05_Text:
  Text::trim(cmd.description).size() > 0 and Text::trim(cmd.shopName).size() > 0 and Text::trim(cmd.paymentMethod).size() > 0 and Text::trim(cmd.description).size() <= 255 and Text::trim(cmd.shopName).size() <= 255 and Text::trim(cmd.paymentMethod).size() <= 100
```

```ocl
-- BR-UC-04-06
-- Source: Product source
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_06_Category:
  cmd.categoryId.oclIsUndefined() or Category.allInstances()->exists(c | c.id = cmd.categoryId)
```

```ocl
-- BR-UC-04-07
-- Source: Assumption
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_07_CurrentVersion:
  Account.allInstances()->exists(a | a.id = cmd.accountId and a.version = cmd.expectedVersion)
```

```ocl
-- BR-UC-04-08
-- Source: Assumption
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_08_Funds:
  (cmd.type = TransactionType::Expense and cmd.status = TransactionStatus::Complete) implies Account.allInstances()->exists(a | a.id = cmd.accountId and a.balance >= cmd.amount)
```

```ocl
-- BR-UC-04-09
-- Source: Assumption
-- Check the resulting balance before database conversion, preventing DECIMAL(18,2) overflow.
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
pre BR_UC_04_09_RevenueBalanceRange:
  (cmd.type = TransactionType::Revenue and cmd.status = TransactionStatus::Complete) implies Account.allInstances()->exists(a | a.id = cmd.accountId and a.balance + cmd.amount < 10000000000000000)
```

```ocl
-- BR-UC-04-10
-- Source: Assumption
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
post BR_UC_04_10_BalanceEffect:
  result.success implies Account.allInstances()->exists(a | a.id = cmd.accountId and a.version = a.version@pre + 1 and a.balance = a.balance@pre + (if cmd.status <> TransactionStatus::Complete then 0 else if cmd.type = TransactionType::Revenue then cmd.amount else -cmd.amount endif endif))
```

```ocl
-- BR-UC-04-11
-- Source: Assumption
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
post BR_UC_04_11_ExactPersistence:
  result.success implies Transaction.allInstances()->one(t | t.id = result.transaction.id and t.accountId = cmd.accountId and t.categoryId = cmd.categoryId and t.date = cmd.date and t.type = cmd.type and t.status = cmd.status and t.description = Text::trim(cmd.description) and t.shopName = Text::trim(cmd.shopName) and t.paymentMethod = Text::trim(cmd.paymentMethod) and t.amount = cmd.amount and t.createdAt = ctx.now and t.receiptId.oclIsUndefined())
```

```ocl
-- BR-UC-04-12
-- Source: Product source
-- Insertion and account version/balance write commit together; version comparison and expense balance check occur within the locked account transaction.
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
post BR_UC_04_12_AtomicFailure:
  not result.success implies Transaction.allInstances()->collect(e | Tuple{id = e.id, accountId = e.accountId, categoryId = e.categoryId, date = e.date, type = e.type, status = e.status, description = e.description, shopName = e.shopName, paymentMethod = e.paymentMethod, amount = e.amount, receiptId = e.receiptId, createdAt = e.createdAt})->asSet() = Transaction.allInstances()@pre->collect(e | Tuple{id = e.id@pre, accountId = e.accountId@pre, categoryId = e.categoryId@pre, date = e.date@pre, type = e.type@pre, status = e.status@pre, description = e.description@pre, shopName = e.shopName@pre, paymentMethod = e.paymentMethod@pre, amount = e.amount@pre, receiptId = e.receiptId@pre, createdAt = e.createdAt@pre})->asSet() and Account.allInstances()->collect(e | Tuple{id = e.id, userId = e.userId, bankName = e.bankName, accountType = e.accountType, branchName = e.branchName, numberCiphertext = e.numberCiphertext, numberFingerprint = e.numberFingerprint, last4 = e.last4, balance = e.balance, version = e.version, createdAt = e.createdAt})->asSet() = Account.allInstances()@pre->collect(e | Tuple{id = e.id@pre, userId = e.userId@pre, bankName = e.bankName@pre, accountType = e.accountType@pre, branchName = e.branchName@pre, numberCiphertext = e.numberCiphertext@pre, numberFingerprint = e.numberFingerprint@pre, last4 = e.last4@pre, balance = e.balance@pre, version = e.version@pre, createdAt = e.createdAt@pre})->asSet()
```

```ocl
-- BR-UC-04-13
-- Source: Product source
context TransactionService::create(ctx: RequestContext, cmd: CreateTransactionCommand): TransactionResult
post BR_UC_04_13_ExactlyOne:
  result.success implies Transaction.allInstances()->size() = Transaction.allInstances()@pre->size() + 1
```

### Related UI

- Product-source UI descriptions: [Use cases rows 64-81](https://docs.google.com/spreadsheets/d/1b6nG8slHLf2CtXZwVHHsNrogvhHNg3lceK6f3B7mKIM/edit#gid=0&range=A64:B81). No Figma node identifier was supplied.

### Related APIs

- [API-TRANSACTION-CREATE](../api/api-transaction-create.md)
- [API-ACCOUNT-LIST](../api/api-account-list.md)
- [API-CATEGORY-LIST](../api/api-category-list.md)

### Notes

See [source mapping](../../coverage-report.md), [review decisions](../../consistency-review.md), and [assumptions](../../ASSUMPTIONS.md). The supplied spreadsheet is specification evidence; no running application or Figma interaction was verified.
