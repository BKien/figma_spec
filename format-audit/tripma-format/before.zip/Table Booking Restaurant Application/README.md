# Table Booking Restaurant Application

[Figma source](FIGMA.md) · [Coverage report](coverage-report.md) · [Domain context](CONTEXT.md) · [Assumptions](ASSUMPTIONS.md) · [Use cases](01-inception/uc/README.md) · [API contracts](01-inception/api/README.md) · [Persistence model](schema.dbml)

This package specifies 20 supported customer and administration goals from one Figma file.
